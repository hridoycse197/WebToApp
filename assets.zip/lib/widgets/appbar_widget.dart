import 'package:flutter/material.dart';
import 'dart:math' as math;

class AppBarWidget extends StatelessWidget {
  const AppBarWidget({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      elevation: 0,
      backgroundColor: Colors.transparent,
      leading: Transform.rotate(
        angle: 90 * math.pi / 180,
        child: const Icon(
          Icons.more_horiz,
          color: Color(0xffE77729),
          size: 40,
        ),
      ),
      actions: [
        Padding(
          padding: EdgeInsets.all(8.0),
          child: CircleAvatar(
            backgroundColor: Color(0xffE77729),
            radius: 22,
            child: CircleAvatar(
              backgroundColor: Colors.black,
              radius: 19,
              child: CircleAvatar(
                backgroundColor: Color(0xffE77729),
                radius: 16,
                child: Image(
                  height: 17,
                  image: AssetImage('assets/Vector.png'),
                ),
              ),
            ),
          ),
        )
      ],
    );
  }
}
