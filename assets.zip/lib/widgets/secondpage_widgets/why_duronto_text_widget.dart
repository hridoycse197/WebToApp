import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class WhyDurontoTextWidget extends StatelessWidget {
  const WhyDurontoTextWidget({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return RichText(
      text: TextSpan(
        children: [
          TextSpan(
            text: ' Duronto?',
            style: GoogleFonts.raleway(
                color: Color(0xffE77729),
                fontSize: 24,
                fontWeight: FontWeight.w600),
          ),
        ],
        text: ' Why',
        style: GoogleFonts.raleway(
            color: Color(0xffFFFFFF),
            fontSize: 24,
            fontWeight: FontWeight.w600),
      ),
    );
  }
}
