import 'package:flutter/material.dart';
import 'dart:math' as math;

import 'package:google_fonts/google_fonts.dart';

import '../widgets/appbar_widget.dart';
import '../widgets/secondpage_widgets/body_container.dart';
import '../widgets/secondpage_widgets/title_text.dart';
import '../widgets/secondpage_widgets/why_duronto_text_widget.dart';

class SecondPage extends StatelessWidget {
  const SecondPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: const PreferredSize(
        child: AppBarWidget(),
        preferredSize: Size.fromHeight(kToolbarHeight),
      ),
      body: SafeArea(
          child: SingleChildScrollView(
        child: Center(
          child: Column(
            children: [
              WhyDurontoTextWidget(),
              SizedBox(
                height: 11,
              ),
              TitleText(),
              SizedBox(
                height: 27,
              ),
              BodyContainer(
                  imagelink: 'assets/globe.png',
                  title: 'Replace Your Website URL'),
              SizedBox(
                height: 27,
              ),
              BodyContainer(
                  imagelink: 'assets/smartphone.png', title: 'Build a App'),
              SizedBox(
                height: 27,
              ),
              BodyContainer(
                  imagelink: 'assets/playstore.png',
                  title: 'Publish on Playstore and App Store'),
            ],
          ),
        ),
      )),
    );
  }
}
