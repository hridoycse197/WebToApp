import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:webtoappnew/widgets/appbar_widget.dart';

import '../widgets/third_screen_widgets/service_title.dart';
import '../widgets/third_screen_widgets/subtitle_widget.dart';
import '../widgets/third_screen_widgets/title_widget.dart';

class ThirdPage extends StatelessWidget {
  ThirdPage({Key? key}) : super(key: key);

  List service_name = [
    'Youtbe',
    'Custom Video',
    'Audio Player',
    'Custom Audio',
    'GIF Images',
    'Vemo Video'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: PreferredSize(
          child: AppBarWidget(),
          preferredSize: Size.fromHeight(kToolbarHeight)),
      body: SafeArea(
          child: Center(
        child: Column(
          children: [
            TitleWidget(),
            SizedBox(
              height: 3,
            ),
            SubTitleWidget(),
            SizedBox(
              height: 3,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 105),
              child: Divider(
                height: 3,
                thickness: 3,
                color: Colors.red.shade900.withOpacity(0.5),
              ),
            ),
            SizedBox(
              height: 21,
            ),
            ServiceTitle(),
            Expanded(
              child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                ),
                itemCount: service_name.length,
                itemBuilder: (BuildContext context, int index) {
                  return Padding(
                    padding: const EdgeInsets.only(
                      top: 30,
                      right: 14,
                    ),
                    child: Container(
                      height: 154,
                      width: 155,
                      decoration: BoxDecoration(
                        color: Colors.red.shade900.withOpacity(0.5),
                        borderRadius: BorderRadius.circular(13),
                        border: Border.all(
                          color: Color(0xffE77729),
                        ),
                      ),
                      child: Column(
                        children: [
                          Container(
                            height: 119,
                            width: 180,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(13),
                                color: Color(0xffE77729)),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Text(
                            service_name[index],
                            style: GoogleFonts.raleway(
                                color: Color(0xffFFFFFF),
                                fontSize: 10,
                                fontWeight: FontWeight.w600),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      )),
    );
  }
}
